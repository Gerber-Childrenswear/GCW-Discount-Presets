# Gerber Childrenswear Speed Benchmark Bundle

Generated: 2026-07-14 UTC

## Scope

This bundle contains synthetic Chrome Lighthouse performance reports for:

- Homepage: `https://www.gerberchildrenswear.com/`
- Product: `https://www.gerberchildrenswear.com/products/1-pack-baby-and-toddler-neutral-sloth-security-blanket-op2010`
- Populated cart: Shopify `/cart/add` redirecting to `/cart`
- Standard Shopify checkout with Shop Pay skipped

No order was submitted and no production configuration was changed.

## Repeated benchmark

The `repeated/` reports contain:

- 5 cold mobile runs for each of the 4 pages (20 reports)
- 5 cold desktop runs for each of the 4 pages (20 reports)
- Lighthouse 12
- Performance category
- Fresh headless Chrome process/profile for every report
- Sequential execution to avoid resource contention between audits

File names follow:

`<mobile|desktop>-<run 1-5>-<home|product|cart|checkout>.json`

## Exploratory reports

The archive-root `gcw-*.json` files contain the initial reports used to identify:

- Duplicate GTM and gtag downloads
- Pixel Guard render-blocking and CPU cost
- Third-party script transfer and execution
- Oversized checkout images
- Checkout extension loading
- Pandectes consent behavior

## Important interpretation notes

- Lighthouse mobile results are simulated/throttled lab measurements, not field Core Web Vitals.
- The cart's approximately 29-second simulated LCP was a late Pandectes consent text candidate. The observed trace LCP in that run was approximately 3.5 seconds.
- Lighthouse reported malformed third-party source maps during several storefront runs. Reports were still generated successfully.
- Checkout URLs and session identifiers are ephemeral. Consumers should redact them when quoting report contents.
- Use medians across the five repeated runs rather than selecting the best or worst result.

## Known identifiers and constraints

- Permitted server-side GTM container: `GTM-N45F3JCC`
- Web/pixel container observed in browser: `GTM-TKW58K8`
- Do not modify `GTM-TKW58K8`.
- Pixel Guard script observed:
  `https://commerce-shield-prod.ncassidy.workers.dev/cs-pixel-guard.js?shop=gerberchildrenswear.myshopify.com`

## Reproduction

See `gcw-speed-benchmark.sh`. It creates new cart/checkout sessions but never enters customer information or submits an order.
