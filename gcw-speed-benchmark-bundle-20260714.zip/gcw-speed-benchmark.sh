#!/usr/bin/env bash
set -u

OUTPUT_DIR="/tmp/gcw-speed-benchmark-$(date -u +%Y%m%dT%H%M%SZ)"
PRODUCT_URL="https://www.gerberchildrenswear.com/products/1-pack-baby-and-toddler-neutral-sloth-security-blanket-op2010"
CART_URL="https://www.gerberchildrenswear.com/cart/add?id=42759449837646&quantity=1"
CHECKOUT_SEED_URL="https://www.gerberchildrenswear.com/cart/42759449837646:1?checkout&skip_shop_pay=true"
CHROME_FLAGS="--headless=new --no-sandbox --disable-dev-shm-usage"

mkdir -p "$OUTPUT_DIR"
printf '%s\n' "$OUTPUT_DIR" > /tmp/gcw-speed-benchmark-latest

run_audit() {
  local mode="$1"
  local run="$2"
  local page="$3"
  local url="$4"
  local preset_args=()

  if [[ "$mode" == "desktop" ]]; then
    preset_args=(--preset=desktop)
  fi

  printf 'START mode=%s run=%s page=%s time=%s\n' "$mode" "$run" "$page" "$(date -u +%FT%TZ)"
  if timeout 180s npx --yes lighthouse@12 "$url" \
    --only-categories=performance \
    --output=json \
    --output-path="$OUTPUT_DIR/${mode}-${run}-${page}.json" \
    --chrome-flags="$CHROME_FLAGS" \
    --quiet \
    "${preset_args[@]}"; then
    printf 'DONE mode=%s run=%s page=%s time=%s\n' "$mode" "$run" "$page" "$(date -u +%FT%TZ)"
  else
    printf 'FAIL mode=%s run=%s page=%s time=%s\n' "$mode" "$run" "$page" "$(date -u +%FT%TZ)"
  fi
}

for mode in mobile desktop; do
  for run in 1 2 3 4 5; do
    run_audit "$mode" "$run" "home" "https://www.gerberchildrenswear.com/"
    run_audit "$mode" "$run" "product" "$PRODUCT_URL"
    run_audit "$mode" "$run" "cart" "$CART_URL"

    checkout_url="$(curl -sS -o /dev/null -w '%{redirect_url}' "$CHECKOUT_SEED_URL")"
    if [[ -n "$checkout_url" ]]; then
      run_audit "$mode" "$run" "checkout" "$checkout_url"
    else
      printf 'FAIL mode=%s run=%s page=checkout reason=no_redirect time=%s\n' "$mode" "$run" "$(date -u +%FT%TZ)"
    fi
  done
done

printf 'COMPLETE output=%s time=%s\n' "$OUTPUT_DIR" "$(date -u +%FT%TZ)"
